# Dijital Günlük AI — Flutter MVP

Flutter ile geliştirilmiş, cihaz-içi çalışan, şifreli dijital günlük uygulaması.